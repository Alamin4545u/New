/**
 * ============================================================================
 * MONETAG ADVERTISING CONFIGURATION FOR TELEGRAM MINI APPS
 * ============================================================================
 * 
 * Replace the placeholder below with your actual Monetag Zone ID.
 * You can also change this interactively within the Mini App's Settings tab.
 * 
 * How to get your Zone ID:
 * 1. Log in to your Monetag Publisher Account (https://monetag.com).
 * 2. Go to "Sites" -> Click "Add Site" -> Enter your HTTPS deployment URL.
 * 3. Once verified, click "Add Zone".
 * 4. Select "Telegram Mini App" or "In-App Interstitial / Rewarded Interstitial".
 * 5. Copy your numeric Zone ID (e.g., "8899123") and paste it below.
 */

// >>> INSERT YOUR MONETAG ZONE ID HERE <<<
export const MONETAG_ADS_ID = "PASTE_MY_MONETAG_ID_HERE";

/**
 * Official Monetag Telegram Mini App SDK Script Source.
 * Default official Monetag CDN: https://alwingulla.com/88/tag.min.js
 * (Some accounts are assigned unique mirror domains in their publisher dashboard)
 */
export const MONETAG_DEFAULT_SDK_URL = "https://alwingulla.com/88/tag.min.js";

/**
 * Minimum cooldown between manual ad triggers (in seconds)
 * This protects your account from rapid repetitive clicks and complies with
 * Monetag anti-spam and ad frequency capping rules.
 */
export const MIN_AD_INTERVAL_SECONDS = 15;
